move_count = 0  # Global variable to count moves

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    if n == 1:  # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

def main():
    global move_count
    move_count = 0  # Reset counter
    n = int(input("Enter number of disks: "))  # Input number of disks
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')  # Find solution recursively
    print("Total number of moves:", move_count)  # Display total moves

main()  # Call the main function




