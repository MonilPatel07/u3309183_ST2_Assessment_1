from tkinter import *
import math

class KochSnowflake:
 def __init__(self):
  window = Tk() # Create a window
  window.title("Koch Snowflake") # Set a title

  self.width = 500
  self.height = 500
  self.canvas = Canvas(window, width = self.width, height = self.height)
  self.canvas.pack()

  # Add a label, an entry, and a button to frame1
  frame1 = Frame(window) # Create and add a frame to window
  frame1.pack()

  Label(frame1, text = "Enter an order: ").pack(side = LEFT)
  self.order = StringVar()
  entry = Entry(frame1, textvariable = self.order, justify = RIGHT).pack(side = LEFT)
  Button(frame1, text = "Display Koch Snowflake", command = self.display).pack(side = LEFT)

  window.mainloop() # Create an event loop

 def display(self):
  self.canvas.delete("line") # Clear previous lines

  # Create equilateral triangle points
  size = 300
  p1 = [self.width/2 - size/2, self.height/2 + size/3]
  p2 = [self.width/2 + size/2, self.height/2 + size/3]
  height = size * math.sqrt(3)/2
  p3 = [self.width/2, self.height/2 - 2*height/3]

  # Draw three sides recursively
  self.kochLine(int(self.order.get()), p1, p2)
  self.kochLine(int(self.order.get()), p2, p3)
  self.kochLine(int(self.order.get()), p3, p1)

 def kochLine(self, order, p1, p2):
  if order == 0: # Base condition
   self.drawLine(p1, p2)
  else:
   # Divide line into 3 segments
   dx = (p2[0] - p1[0]) / 3
   dy = (p2[1] - p1[1]) / 3
   pA = [p1[0] + dx, p1[1] + dy]
   pB = [p1[0] + 2*dx, p1[1] + 2*dy]

   # Calculate peak of outward equilateral triangle
   angle = math.radians(60)
   px = pA[0] + math.cos(angle)*(pB[0]-pA[0]) - math.sin(angle)*(pB[1]-pA[1])
   py = pA[1] + math.sin(angle)*(pB[0]-pA[0]) + math.cos(angle)*(pB[1]-pA[1])
   pC = [px, py]

   # Recursively draw 4 line segments
   self.kochLine(order - 1, p1, pA)
   self.kochLine(order - 1, pA, pC)
   self.kochLine(order - 1, pC, pB)
   self.kochLine(order - 1, pB, p2)

 def drawLine(self, p1, p2):
  self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags = "line")

# Run the program
KochSnowflake()